![pp](stock-img.png)
## Trevor J Young 
---
# AAS INFO TECHNOLOGY, TECHNICAL SUPPORT OPTION
Hard working and family oriented focused on graduating from pccc in order to transfer to a 4 year college to earn a bachelor's degree. While maintaining college class I also strive to find better working environments that can teach me more about the field I am majoring in.

## Experience 

# Rental Technician
Fairmount car and truck rental - Hackensack, NJ May 2020 to Present This job includes checking
all vehicles for proper maintenance if it is not up to date you must take it for maintenance or
solve the issue yourself. When a customer rents a vehicle you must walk around the vehicle with
the customer so you can check the vehicle for existing damage, you must repeat this process
when the customer comes back to make sure there is no new damage. When business is slow you
can clean the vehicles to make sure every customer is satisfied when they use our rental service.

# Hardside
Bed Bath & Beyond - Paramus, NJ February 2021 to April 2021 This is a retail job where you
must help any customer in the store that is in the hard side department find what they are looking
for, and if you cannot find it help them order it alone. When there were not many customers in
the store you either restocked shelves and or put back returned items.

# Seasonal Package Handler
UPS - Saddle Brook, NJ September 2022 to December 2022 Very simple seasonal job where my
role was to load trucks we would scan the packages to make sure they belonged to the truck.
Next, we would make walls with the packages to load the truck until it is full. Lastly, any
packages that do not belong to your truck must be brought to the proper dock.

## Education 
* High school diploma
Diana C. Lobosco STEM Academy - Wayne, NJ
September 2018 to June 2022
* Current education
  Passaic County Community College 