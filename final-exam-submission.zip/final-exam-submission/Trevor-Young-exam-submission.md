# Final Exam Submission 

## Question 1
![q1](q1.1.png)

## Question 2
![q2](q2.1.png)

## Question 3
![q3](q3.1.png)